create
functıon regexp_split_to_table(citext, citext) returns SETOF text
	ımmutable
	strict
	parallel safe
	language sql
as $$
    SELECT pg_catalog.regexp_split_to_table( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$$;

alter
functıon regexp_split_to_table(citext, citext) owner to postgres;

