create
functıon strpos(citext, citext) returns integer
	ımmutable
	strict
	parallel safe
	language sql
as $$
    SELECT pg_catalog.strpos( pg_catalog.lower( $1::pg_catalog.text ), pg_catalog.lower( $2::pg_catalog.text ) );
$$;

alter
functıon strpos(citext, citext) owner to postgres;

